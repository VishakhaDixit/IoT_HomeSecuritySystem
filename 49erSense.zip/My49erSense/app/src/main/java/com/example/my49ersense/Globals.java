package com.example.my49ersense;

public class Globals {
    public static final String IP = "192.168.10.103";
    public static final String PHP_URL = "http://" + IP + "/LoginRegister/";
}
